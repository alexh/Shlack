module Main where

import Client
import System.IO

main :: IO ()
main = Client.clientMain