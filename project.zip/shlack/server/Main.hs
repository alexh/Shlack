module Main where

import Server
import System.IO

main :: IO ()
main = Server.serverMain