cp shlack/.stack-work/dist/x86_64-osx/Cabal-1.24.2.0/build/client/client client
cp shlack/.stack-work/dist/x86_64-osx/Cabal-1.24.2.0/build/server/server server